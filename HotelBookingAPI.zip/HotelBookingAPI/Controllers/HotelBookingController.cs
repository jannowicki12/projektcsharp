﻿using HotelBookingAPI.Data;
using HotelBookingAPI.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace HotelBookingAPI.Controllers
{ 
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class HotelBookingController : Controller
    {
        private readonly ApiContext ApiContext;

        public HotelBookingController(ApiContext ApiContext)
        {
            this.ApiContext = ApiContext;
        }

        [HttpPost]
        public async Task<IActionResult> Create(HotelBooking booking)
        {
            if(booking.Id == 0)
            {
                await ApiContext.Bookings.AddAsync(booking);
            }
            await ApiContext.SaveChangesAsync();

            return Ok(booking);
        }
        [HttpPost]
        public async Task<IActionResult> Edit(HotelBooking booking)
        {
            var bookingInDb = await ApiContext.Bookings.FindAsync(booking.Id);
            if (bookingInDb == null)
                return new JsonResult(NotFound());
            bookingInDb = booking;

            await ApiContext.SaveChangesAsync();

            return Ok(booking);
        }

        [HttpDelete]
        public async Task<IActionResult> Delete(int id)
        {
            var result = await ApiContext.Bookings.FindAsync(id);
            if (result == null)
                return new JsonResult(NotFound());

            ApiContext.Bookings.Remove(result);
            await ApiContext.SaveChangesAsync();
            return new JsonResult(NoContent());
        }

        [HttpGet]
        public async Task<IActionResult> Get(int id)
        {
            var result = await ApiContext.Bookings.FindAsync(id);

            if (result == null)
                return new JsonResult(NotFound());

            return Ok(result);
        }
        [HttpGet()]
        public async Task<IActionResult> GetAll()
        {
            var result = await ApiContext.Bookings.ToListAsync();

            return Ok(result);
        }
    }
}
