﻿using Microsoft.AspNetCore.Mvc;

namespace HotelBookingAPI.Model
{
    public class HotelBooking
    {
        public int Id { get; set; }
        public int RoomNumber { get; set; }
        public string? ClientName { get; set; }
    }
}
